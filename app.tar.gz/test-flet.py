from flet import *

def main(page: Page):
    container = Container(
        width = 500, height = 500, bgcolor = 'green',
        content = Text(
            'Welcome to MY world. HAHAHA. this is IAN as fuck',
            size = 40
        )
    )
    page.add(container)

app(target=main, view=WEB_BROWSER)